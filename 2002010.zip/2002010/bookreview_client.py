from __future__ import print_function

import logging
from re import template

import grpc
import bookreview_pb2
import bookreview_pb2_grpc

def run():

    with grpc.insecure_channel('localhost:50051') as channel:
        stub = bookreview_pb2_grpc.bookreviewStub(channel)
        
        # Create Review
        response = stub.create_review(bookreview_pb2.review(bookname = "Book", review = "Good book"))
        print(response.review_reponse)

        # Create Review
        response = stub.create_review(bookreview_pb2.review(bookname = "Beyond good and evil", review = "Beyond me"))
        print(response.review_reponse)

        # Retrieve History
        response = stub.retrieve(bookreview_pb2.retrieval(retrieve = "retrieve"))
        print(response.booklist)

        # Query books
        reponse = stub.query(bookreview_pb2.queries(query = "Book"))
        print(reponse.bookname, reponse.review)



if __name__ == '__main__':
    logging.basicConfig()
    run()
